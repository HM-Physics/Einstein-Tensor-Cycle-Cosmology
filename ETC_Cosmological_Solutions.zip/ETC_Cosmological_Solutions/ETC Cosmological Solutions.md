# ETC Cosmological Solutions
## README File for Zenodo Deposition

Hirokazu Maruyama  
April 28, 2025

## Summary
This archive contains Mathematica notebooks for analyzing cosmological (de Sitter) solutions in ETC[^1] gravity theory, along with corresponding PDF files. 
Each notebook implements analysis for curvature indices k = −1, 0, 1.

## Overview
This archive provides Mathematica notebooks together with pre–generated PDF outputs for the study of de Sitter cosmological solutions in the ETC (Einstein-Tensor-Cycle) gravity framework. 
Solutions are given for all three spatial–curvature indices k = −1, 0, 1.

## Repository Contents
* `ETC_Cosmological_Solutions/ETC_deSitter_k-1.nb` – Mathematica notebook for the open (k = −1) universe case.
* `ETC_Cosmological_Solutions/ETC_deSitter_k-1.pdf` – PDF rendering of the above notebook.
* `ETC_Cosmological_Solutions/ETC_deSitter_k0.nb` – Notebook for the flat (k = 0) universe case.
* `ETC_Cosmological_Solutions/ETC_deSitter_k0.pdf` – PDF rendering of the above notebook.
* `ETC_Cosmological_Solutions/ETC_deSitter_k1.nb` – Notebook for the closed (k = 1) universe case.
* `ETC_Cosmological_Solutions/ETC_deSitter_k1.pdf` – PDF rendering of the above notebook.

## Contact
For questions or bug reports please contact:  
Hirokazu Maruyama  
etctransformation@jcom.zaq.ne.jp

